<!-- Created with <STRONG><CONTACT> -->
<!-- http://www.stronghtml.com/ -->
<html>
<head>
<title>mailform</title>
<style type="text/css">

/* background image */
body
{
background-image: url('http://www.15926.info/parnassia.jpg');
background-repeat: no-repeat;
background-attachment: fixed
}

/* Left Column Style */
.contactformLeftColumn {
 padding-right:5px;
 padding-bottom:5px;
}

/* Right Column Style */
.contactformRightColumn {
 padding-right:5px;
 padding-bottom:5px;
}

/* Text Field Style */
.contactformTextField {
 width:250px;
 border: 1px solid #999999;
 color:#333333;
 padding-left:2px;
}

/* Text Area Style */
.contactformTextArea {
 width:500px;
 height:300px;
 border: 1px solid #999999;
 color:#333333;
 padding-left:2px;
}

/* Check Box Style */
.contactformCheckBox {
}

/* Submit Button Style */
.contactformSubmit {
 border: 1px solid #999999;
}

/* Thank You Message Style */
.contactformThankYou {
}
</style>
</head>
<body>
<p>&nbsp;</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<p align="center"><b>To: Hans Teijgeler</b></p>

 <form name="contactform" method="post" action="">
 <input type="hidden" name="contactformseen" value="y">
 <table border="0" cellspacing="0" cellpadding="0" align="center">
 <tr>
 <td align="right" valign="middle" class="contactformLeftColumn"><b>From: &nbsp;</b></td>
 <td align="left" class="contactformRightColumn"><input name="contactformvar2" id="contactformvar2" type="text" class="contactformTextField" value=""></td>
 </tr>
 <tr>
 <td align="right" valign="middle" class="contactformLeftColumn"><b>E-mail: &nbsp;</b></td>
 <td align="left" class="contactformRightColumn"><input name="contactformvar3" id="contactformvar3" type="text" class="contactformTextField" value=""></td>
 </tr>
 <tr>
 <td align="right" valign="middle" class="contactformLeftColumn"><b>Subject: &nbsp;</b></td>
 <td align="left" class="contactformRightColumn"><input name="contactformvar4" id="contactformvar4" type="text" class="contactformTextField" value=""></td>
 </tr>
 <tr>
 <td align="right" valign="top" class="contactformLeftColumn"><b>Message: &nbsp;</b></td>
 <td align="left" class="contactformRightColumn"><textarea name="contactformvar5" id="contactformvar5" class="contactformTextArea"></textarea></td>
 </tr>
 <tr>
 <td colspan="2" align="center"><input type="submit" name="Submit" value="Send" class="contactformSubmit"></td>
 </tr>
 </table>
 </form></body>
</html> 